package com.example.tochsm

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class AccountSettingsActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_account_settings)
    }
}